import { Link, useLocation } from "wouter";
import { TEACHER_WA } from "@/lib/constants";

export default function Navbar() {
  const [location] = useLocation();

  const links = [
    { href: "/", label: "Home" },
    { href: "/test", label: "Online Test" },
    { href: "/chat", label: "Study Assistant" },
  ];

  return (
    <nav className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-black text-sm">A</div>
          <div>
            <div className="font-black text-white text-sm leading-tight">ANA CLASSES</div>
            <div className="text-xs text-indigo-400 font-medium leading-tight">Nematullah Sir</div>
          </div>
        </Link>

        <div className="hidden md:flex items-center gap-1">
          {links.map(l => (
            <Link key={l.href} href={l.href}
              className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${location === l.href ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-white hover:bg-slate-800"}`}>
              {l.label}
            </Link>
          ))}
        </div>

        <a
          href={`https://wa.me/${TEACHER_WA}`}
          target="_blank"
          rel="noopener noreferrer"
          className="bg-gradient-to-r from-green-500 to-emerald-500 text-white text-xs font-black px-4 py-2 rounded-xl hover:scale-105 transition-all shadow-lg shadow-green-500/20"
        >
          WhatsApp Join
        </a>
      </div>

      {/* Mobile nav */}
      <div className="md:hidden flex border-t border-slate-800">
        {links.map(l => (
          <Link key={l.href} href={l.href}
            className={`flex-1 text-center py-2.5 text-xs font-bold transition-all ${location === l.href ? "text-indigo-400 border-b-2 border-indigo-500" : "text-slate-500"}`}>
            {l.label}
          </Link>
        ))}
      </div>
    </nav>
  );
}
