export const TEACHER_WA = "917282849702";

export const CLASSES = Array.from({ length: 12 }, (_, i) => i + 1);
export const SECTIONS = ["A", "B", "C", "D", "E"];
export const GENDERS = ["Male", "Female", "Other"];

export const SUBJECTS_BY_CLASS: Record<number, string[]> = {
  1: ["Hindi", "English", "Mathematics", "EVS", "Drawing"],
  2: ["Hindi", "English", "Mathematics", "EVS", "Drawing"],
  3: ["Hindi", "English", "Mathematics", "EVS", "General Knowledge"],
  4: ["Hindi", "English", "Mathematics", "EVS", "General Knowledge"],
  5: ["Hindi", "English", "Mathematics", "Science", "Social Studies", "General Knowledge"],
  6: ["Hindi", "English", "Mathematics", "Science", "Social Science", "Sanskrit"],
  7: ["Hindi", "English", "Mathematics", "Science", "Social Science", "Sanskrit"],
  8: ["Hindi", "English", "Mathematics", "Science", "Social Science", "Sanskrit"],
  9: ["Hindi", "English", "Mathematics", "Science", "Social Science", "Sanskrit"],
  10: ["Hindi", "English", "Mathematics", "Science", "Social Science", "Sanskrit"],
  11: ["Hindi", "English", "Mathematics", "Physics", "Chemistry", "Biology", "History", "Political Science", "Economics", "Geography", "Computer Science"],
  12: ["Hindi", "English", "Mathematics", "Physics", "Chemistry", "Biology", "History", "Political Science", "Economics", "Geography", "Computer Science"],
};

export const SUBJECT_EMOJI: Record<string, string> = {
  Mathematics: "🔢", Physics: "⚛️", Chemistry: "🧪", Biology: "🌿",
  Science: "🔬", English: "📖", Hindi: "📝", Sanskrit: "🕉️",
  "Social Science": "🌍", "Social Studies": "🌍", History: "🏛️",
  Geography: "🗺️", Economics: "📊", "Political Science": "⚖️",
  "Computer Science": "💻", EVS: "🌱", Drawing: "🎨", "General Knowledge": "💡",
};

export const SUBJECT_GRADIENT: Record<string, string> = {
  Mathematics: "from-blue-600 to-cyan-500",
  Physics: "from-purple-600 to-violet-500",
  Chemistry: "from-green-600 to-emerald-500",
  Biology: "from-emerald-700 to-green-500",
  Science: "from-teal-600 to-cyan-500",
  English: "from-yellow-600 to-amber-500",
  Hindi: "from-orange-600 to-red-500",
  Sanskrit: "from-red-700 to-rose-500",
  "Social Science": "from-pink-600 to-rose-500",
  "Social Studies": "from-pink-600 to-rose-500",
  History: "from-amber-600 to-yellow-500",
  Geography: "from-lime-600 to-green-500",
  Economics: "from-cyan-600 to-blue-500",
  "Political Science": "from-indigo-600 to-blue-500",
  "Computer Science": "from-violet-600 to-purple-500",
  EVS: "from-green-500 to-lime-500",
  Drawing: "from-rose-500 to-pink-500",
  "General Knowledge": "from-sky-600 to-blue-500",
};

export const MOTIVATIONAL = [
  { quote: "Padhai wo hathiyaar hai jo aapko duniya badalne ki taqat deta hai.", author: "Nematullah Sir", emoji: "⚔️" },
  { quote: "Haar baar girna zaroori hai, kyunki uthna tab hi seekhte hain.", author: "Nematullah Sir", emoji: "🌱" },
  { quote: "Sapne wo nahi jo neend mein aate hain, sapne wo hain jo neend nahi aane dete.", author: "Dr. APJ Abdul Kalam", emoji: "🚀" },
  { quote: "Mushkil raastay hi sab se khoobsoorat manzilein dete hain.", author: "Nematullah Sir", emoji: "🏔️" },
  { quote: "Mehnat karo aaj, aaram karega kal ki zindagi.", author: "Nematullah Sir", emoji: "💪" },
  { quote: "Shiksha woh nahin jo school mein milti hai, shiksha woh hai jo zindagi sikhati hai.", author: "Albert Einstein", emoji: "🎓" },
  { quote: "Sirf ek kadam aage badho, baaki raasta khud ban jaata hai.", author: "Nematullah Sir", emoji: "👣" },
];

export const STUDENT_REVIEWS = [
  { name: "Rahul Kumar", cls: "Class 10", rating: 5, review: "Nematullah Sir ke padhane ka tarika bahut acha hai. Maths mein weak tha, ab 95% aata hai! ANA CLASSES ne meri zindagi badal di.", avatar: "R", color: "from-blue-500 to-cyan-400" },
  { name: "Priya Sharma", cls: "Class 8", rating: 5, review: "Online tests bahut helpful hain. Har subject mein improvement dekhi. Sir bahut patience se samjhate hain. Best coaching in Delhi!", avatar: "P", color: "from-pink-500 to-rose-400" },
  { name: "Mohammed Arif", cls: "Class 12", rating: 5, review: "Physics aur Chemistry mein bahut problem thi. Sir ne step by step samjhaya. Board exam mein 88% aaya! Shukriya ANA CLASSES.", avatar: "M", color: "from-green-500 to-emerald-400" },
  { name: "Anjali Singh", cls: "Class 6", rating: 5, review: "Chhote se classes hain, personally dhyan dete hain. Mere bacche ko bahut fayda hua. 7 saal ka experience clearly dikhta hai.", avatar: "A", color: "from-yellow-500 to-amber-400" },
  { name: "Rohan Verma", cls: "Class 9", rating: 5, review: "Doubt solving chatbot ne bahut help ki raat ko padhte waqt. Instant jawab milta hai. Ekdum best platform!", avatar: "R", color: "from-purple-500 to-violet-400" },
  { name: "Fatima Bano", cls: "Class 11", rating: 5, review: "Science stream mein struggle kar rahi thi. Sir ne ek ek concept clear kiya. Ab confidently exam deti hoon. Thank you ANA CLASSES!", avatar: "F", color: "from-orange-500 to-red-400" },
];

export const STUDY_TIPS = [
  { icon: "📅", title: "Daily Routine Banao", tip: "Subah uthke ek ghanta padho. Subah ka dimag fresh hota hai, sab jaldi yaad hota hai." },
  { icon: "✍️", title: "Notes Banao", tip: "Sirf padhna kaafi nahi — likhte bhi jao. Likhne se 70% zyada yaad rehta hai." },
  { icon: "🎯", title: "Target Set Karo", tip: "Har din ka ek chota target banao. 'Aaj yeh chapter complete karunga' — aisa sochke padho." },
  { icon: "🔁", title: "Revision Karo", tip: "Padha hua 24 ghante mein bhool jaate hain agar revision na ho. Roz 15 min revision karo." },
  { icon: "🧘", title: "Break Lo", tip: "50 min padhne ke baad 10 min ka break lo. Dimag ko rest chahiye, tabhi acha kaam karta hai." },
  { icon: "❓", title: "Sawaal Poochho", tip: "Koi bhi doubt clear karo turant. Ek uljhan hazzaron problems create karti hai aage." },
];
