import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import {
  TEACHER_WA, SUBJECTS_BY_CLASS, SUBJECT_EMOJI, SUBJECT_GRADIENT,
  MOTIVATIONAL, STUDENT_REVIEWS, STUDY_TIPS,
} from "@/lib/constants";

function Stars({ n = 5 }: { n?: number }) {
  return <span className="text-yellow-400 text-sm">{"★".repeat(n)}</span>;
}

function MotivCard() {
  const [idx, setIdx] = useState(0);
  const [fade, setFade] = useState(true);

  const cycle = () => {
    setFade(false);
    setTimeout(() => { setIdx(i => (i + 1) % MOTIVATIONAL.length); setFade(true); }, 300);
  };

  useEffect(() => {
    const t = setInterval(cycle, 5000);
    return () => clearInterval(t);
  }, []);

  const m = MOTIVATIONAL[idx];
  return (
    <div
      onClick={cycle}
      className="cursor-pointer bg-gradient-to-br from-indigo-900/70 to-purple-900/70 border border-indigo-500/30 rounded-2xl p-6 transition-opacity duration-300"
      style={{ opacity: fade ? 1 : 0 }}
    >
      <div className="text-4xl mb-3">{m.emoji}</div>
      <p className="text-white font-semibold text-base leading-relaxed italic mb-3">"{m.quote}"</p>
      <div className="flex items-center justify-between">
        <p className="text-indigo-300 text-sm font-bold">— {m.author}</p>
        <div className="flex gap-1">
          {MOTIVATIONAL.map((_, i) => (
            <div key={i} className={`w-1.5 h-1.5 rounded-full transition-all ${i === idx ? "bg-yellow-400" : "bg-white/20"}`} />
          ))}
        </div>
      </div>
    </div>
  );
}

function ReviewsCarousel() {
  const [idx, setIdx] = useState(0);
  const total = STUDENT_REVIEWS.length;

  useEffect(() => {
    const t = setInterval(() => setIdx(i => (i + 1) % total), 4000);
    return () => clearInterval(t);
  }, []);

  const r = STUDENT_REVIEWS[idx];
  return (
    <div className="relative">
      <div className="bg-slate-800/60 border border-slate-700 rounded-2xl p-6 min-h-[180px] transition-all duration-300">
        <div className="flex items-center gap-3 mb-3">
          <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${r.color} flex items-center justify-center text-white font-black text-lg`}>
            {r.avatar}
          </div>
          <div>
            <div className="font-bold text-white text-sm">{r.name}</div>
            <div className="text-xs text-slate-400">{r.cls}</div>
            <Stars n={r.rating} />
          </div>
        </div>
        <p className="text-slate-300 text-sm leading-relaxed">"{r.review}"</p>
      </div>
      <div className="flex justify-center gap-1.5 mt-3">
        {STUDENT_REVIEWS.map((_, i) => (
          <button
            key={i}
            onClick={() => setIdx(i)}
            className={`w-1.5 h-1.5 rounded-full transition-all ${i === idx ? "bg-indigo-400 w-4" : "bg-slate-600"}`}
          />
        ))}
      </div>
    </div>
  );
}

export default function Home() {
  const [selectedClass, setSelectedClass] = useState(10);
  const subjects = SUBJECTS_BY_CLASS[selectedClass] || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 text-white">
      {/* Hero */}
      <section className="relative overflow-hidden px-4 pt-16 pb-20 text-center">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-900/40 via-transparent to-transparent pointer-events-none" />
        <div className="relative max-w-3xl mx-auto animate-fadeIn">
          <div className="inline-flex items-center gap-2 bg-indigo-900/60 border border-indigo-700/50 rounded-full px-4 py-1.5 text-xs font-bold text-indigo-300 mb-6">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            7 Saal Ka Experience • New Delhi
          </div>
          <h1 className="text-5xl md:text-7xl font-black mb-4 leading-tight">
            <span className="bg-gradient-to-r from-white via-indigo-200 to-purple-300 bg-clip-text text-transparent">ANA</span>
            <br />
            <span className="bg-gradient-to-r from-yellow-400 to-amber-400 bg-clip-text text-transparent">CLASSES</span>
          </h1>
          <p className="text-slate-300 text-lg mb-2 font-medium">Nematullah Sir ke saath padho, kamiyaab bano</p>
          <p className="text-slate-500 text-sm mb-10">Class 1 se 12 tak • Delhi ka sabse bharosemand coaching</p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/test"
              className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-black px-8 py-4 rounded-2xl text-base hover:scale-105 transition-all shadow-xl shadow-indigo-500/25">
              Online Test Do
            </Link>
            <Link href="/chat"
              className="bg-slate-800 border border-slate-700 text-white font-bold px-8 py-4 rounded-2xl text-base hover:bg-slate-700 transition-all">
              AI Study Help
            </Link>
            <a
              href={`https://wa.me/${TEACHER_WA}`}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gradient-to-r from-green-600 to-emerald-600 text-white font-black px-8 py-4 rounded-2xl text-base hover:scale-105 transition-all shadow-xl shadow-green-500/20"
            >
              WhatsApp Join
            </a>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="px-4 pb-16">
        <div className="max-w-4xl mx-auto grid grid-cols-3 gap-4">
          {[
            { val: "7+", label: "Saal Experience" },
            { val: "1000+", label: "Students Padhe" },
            { val: "Class 1-12", label: "All Subjects" },
          ].map(s => (
            <div key={s.label} className="bg-slate-800/60 border border-slate-700 rounded-2xl p-5 text-center">
              <div className="text-3xl font-black text-yellow-400 mb-1">{s.val}</div>
              <div className="text-xs text-slate-400 font-semibold">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Motivational */}
      <section className="px-4 pb-16">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-xl font-black text-center text-white mb-6">
            <span className="text-indigo-400">Nematullah Sir</span> Ka Sandesh
          </h2>
          <MotivCard />
        </div>
      </section>

      {/* Subjects by Class */}
      <section className="px-4 pb-16">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl font-black text-center text-white mb-2">Subjects Explore Karo</h2>
          <p className="text-slate-400 text-sm text-center mb-6">Class choose karo aur subjects dekho</p>

          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {Array.from({ length: 12 }, (_, i) => i + 1).map(cls => (
              <button
                key={cls}
                onClick={() => setSelectedClass(cls)}
                className={`w-10 h-10 rounded-xl font-black text-sm transition-all ${selectedClass === cls
                  ? "bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-lg shadow-indigo-500/30"
                  : "bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white"}`}
              >
                {cls}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {subjects.map(sub => (
              <div
                key={sub}
                className={`bg-gradient-to-br ${SUBJECT_GRADIENT[sub] || "from-slate-600 to-slate-500"} rounded-2xl p-4 text-center hover:scale-105 transition-all cursor-default shadow-lg`}
              >
                <div className="text-3xl mb-2">{SUBJECT_EMOJI[sub] || "📚"}</div>
                <div className="text-white font-bold text-sm">{sub}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Study Tips */}
      <section className="px-4 pb-16">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-black text-center text-white mb-2">Study Tips</h2>
          <p className="text-slate-400 text-sm text-center mb-8">Nematullah Sir ke proven tips</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {STUDY_TIPS.map((t, i) => (
              <div key={i} className="bg-slate-800/60 border border-slate-700 rounded-2xl p-5 hover:border-indigo-500/50 transition-all">
                <div className="text-3xl mb-3">{t.icon}</div>
                <div className="font-black text-yellow-300 text-sm mb-2">{t.title}</div>
                <p className="text-slate-400 text-xs leading-relaxed">{t.tip}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="px-4 pb-16">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-2xl font-black text-center text-white mb-2">Student Reviews</h2>
          <p className="text-slate-400 text-sm text-center mb-8">Hamare students kya kehte hain</p>
          <ReviewsCarousel />
        </div>
      </section>

      {/* CTA */}
      <section className="px-4 pb-20">
        <div className="max-w-2xl mx-auto bg-gradient-to-br from-indigo-900/80 to-purple-900/80 border border-indigo-500/30 rounded-3xl p-10 text-center">
          <h2 className="text-3xl font-black text-white mb-3">Shuru Karo Aaj Se!</h2>
          <p className="text-slate-300 text-sm mb-8">Online test do, AI se padho, ya WhatsApp pe join karo</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/test" className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-black px-6 py-3 rounded-xl hover:scale-105 transition-all">
              Test Do
            </Link>
            <a
              href={`https://wa.me/${TEACHER_WA}`}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gradient-to-r from-green-600 to-emerald-600 text-white font-black px-6 py-3 rounded-xl hover:scale-105 transition-all"
            >
              WhatsApp Join Karo
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
