import { useState, useEffect, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListAnthropicConversations,
  getListAnthropicConversationsQueryKey,
  useCreateAnthropicConversation,
  useGetAnthropicConversation,
  getGetAnthropicConversationQueryKey,
  useDeleteAnthropicConversation,
} from "@workspace/api-client-react";
import { STUDY_TIPS } from "@/lib/constants";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  img?: string;
}

async function streamMessage(
  conversationId: number,
  content: string,
  onChunk: (text: string) => void
) {
  const res = await fetch(
    `${BASE}/api/anthropic/conversations/${conversationId}/messages`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content }),
    }
  );
  if (!res.body) return;
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() || "";
    for (const line of lines) {
      if (line.startsWith("data: ")) {
        try {
          const json = JSON.parse(line.slice(6));
          if (json.content) onChunk(json.content);
          if (json.done) return;
        } catch { /* ignore parse errors */ }
      }
    }
  }
}

const QUICK_Q = [
  "Maths formula yaad karne ka tarika?",
  "Science ke liye best tips?",
  "Exam stress kaise kam karein?",
  "Time table kaise banayein?",
];

const WELCOME = `Namaste! Main ANA CLASSES ka Study Assistant hoon.

Aap mujhse pooch sakte hain:
- Koi bhi subject ka sawaal
- Homework help
- Concept samajhna
- Exam preparation tips

Chalo shuru karte hain!`;

export default function Chat() {
  const qc = useQueryClient();
  const [activeId, setActiveId] = useState<number | null>(null);
  const [localMsgs, setLocalMsgs] = useState<ChatMessage[]>([{ role: "assistant", content: WELCOME }]);
  const [input, setInput] = useState("");
  const [imgB64, setImgB64] = useState<string | null>(null);
  const [imgPrev, setImgPrev] = useState<string | null>(null);
  const [streaming, setStreaming] = useState(false);
  const [tab, setTab] = useState<"chat" | "tips">("chat");
  const [newTitle, setNewTitle] = useState("");
  const [showNew, setShowNew] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const { data: conversations = [] } = useListAnthropicConversations();
  const { data: activeConv } = useGetAnthropicConversation(
    activeId!,
    { query: { enabled: !!activeId, queryKey: getGetAnthropicConversationQueryKey(activeId!) } }
  );
  const createConv = useCreateAnthropicConversation();
  const deleteConv = useDeleteAnthropicConversation();

  useEffect(() => {
    if (activeConv?.messages) {
      setLocalMsgs(activeConv.messages.map(m => ({ role: m.role as "user" | "assistant", content: m.content })));
    }
  }, [activeConv]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [localMsgs, streaming]);

  const pickImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = ev => {
      const result = ev.target?.result as string;
      setImgB64(result.split(",")[1]);
      setImgPrev(result);
    };
    r.readAsDataURL(f);
    e.target.value = "";
  };

  const handleCreateConv = () => {
    const title = newTitle.trim() || "Naya Sawaal";
    createConv.mutate(
      { data: { title } },
      {
        onSuccess: (conv) => {
          qc.invalidateQueries({ queryKey: getListAnthropicConversationsQueryKey() });
          setActiveId(conv.id);
          setLocalMsgs([{ role: "assistant", content: WELCOME }]);
          setNewTitle("");
          setShowNew(false);
        },
      }
    );
  };

  const handleDelete = (id: number) => {
    deleteConv.mutate(
      { id },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListAnthropicConversationsQueryKey() });
          if (activeId === id) { setActiveId(null); setLocalMsgs([{ role: "assistant", content: WELCOME }]); }
        },
      }
    );
  };

  const send = async () => {
    if (!input.trim() && !imgB64) return;
    if (!activeId) {
      // Auto-create conversation
      const title = input.slice(0, 40) || "Naya Sawaal";
      createConv.mutate(
        { data: { title } },
        {
          onSuccess: async (conv) => {
            qc.invalidateQueries({ queryKey: getListAnthropicConversationsQueryKey() });
            setActiveId(conv.id);
            await doSend(conv.id);
          },
        }
      );
      return;
    }
    await doSend(activeId);
  };

  const doSend = async (convId: number) => {
    const userContent = input || "[Photo uploaded]";
    const userMsg: ChatMessage = { role: "user", content: userContent, img: imgPrev || undefined };
    setLocalMsgs(p => [...p, userMsg]);
    setInput(""); setImgB64(null); setImgPrev(null);
    setStreaming(true);

    let assistantText = "";
    setLocalMsgs(p => [...p, { role: "assistant", content: "" }]);

    try {
      await streamMessage(convId, userContent, (chunk) => {
        assistantText += chunk;
        setLocalMsgs(p => {
          const updated = [...p];
          updated[updated.length - 1] = { role: "assistant", content: assistantText };
          return updated;
        });
      });
      qc.invalidateQueries({ queryKey: getGetAnthropicConversationQueryKey(convId) });
    } catch {
      setLocalMsgs(p => {
        const updated = [...p];
        updated[updated.length - 1] = { role: "assistant", content: "Network error aayi. Dobara try karo! 🙏" };
        return updated;
      });
    }
    setStreaming(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 flex">
      {/* Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-r border-slate-800 bg-slate-950/80 flex-shrink-0">
        <div className="p-4 border-b border-slate-800">
          <div className="text-sm font-black text-white mb-3">Conversations</div>
          {showNew ? (
            <div className="flex gap-2">
              <input
                value={newTitle}
                onChange={e => setNewTitle(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleCreateConv()}
                placeholder="Title..."
                className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs outline-none focus:border-indigo-500"
                autoFocus
              />
              <button onClick={handleCreateConv} className="bg-indigo-600 text-white text-xs px-3 py-2 rounded-xl font-bold">+</button>
            </div>
          ) : (
            <button
              onClick={() => setShowNew(true)}
              className="w-full bg-indigo-600/20 border border-indigo-600/40 text-indigo-400 rounded-xl py-2 text-xs font-bold hover:bg-indigo-600/30 transition-all"
            >
              + Naya Chat
            </button>
          )}
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {conversations.map(c => (
            <div
              key={c.id}
              className={`group flex items-center gap-2 p-3 rounded-xl cursor-pointer transition-all ${activeId === c.id ? "bg-indigo-600/20 border border-indigo-600/30" : "hover:bg-slate-800"}`}
              onClick={() => setActiveId(c.id)}
            >
              <span className="flex-1 text-xs text-slate-300 truncate font-medium">{c.title}</span>
              <button
                onClick={e => { e.stopPropagation(); handleDelete(c.id); }}
                className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-red-400 text-xs w-5 h-5 flex items-center justify-center"
              >✕</button>
            </div>
          ))}
          {conversations.length === 0 && (
            <p className="text-xs text-slate-600 text-center py-4">Koi chat nahi. Naya shuru karo!</p>
          )}
        </div>
      </aside>

      {/* Main chat */}
      <div className="flex-1 flex flex-col max-h-screen">
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-800 to-purple-800 p-4 flex items-center gap-3 flex-shrink-0">
          <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center text-xl">👨‍🏫</div>
          <div className="flex-1">
            <div className="font-black text-white text-sm">ANA CLASSES Study Assistant</div>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              <span className="text-xs text-purple-200">Online · Nematullah Sir</span>
            </div>
          </div>
          <div className="flex gap-2">
            {(["chat", "tips"] as const).map(t => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${tab === t ? "bg-white/20 text-white" : "text-white/50 hover:text-white/80"}`}
              >
                {t === "chat" ? "Chat" : "Tips"}
              </button>
            ))}
          </div>
        </div>

        {tab === "tips" ? (
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            <p className="text-center text-indigo-300 text-xs font-bold">Nematullah Sir ke Study Tips</p>
            {STUDY_TIPS.map((t, i) => (
              <div key={i} className="bg-slate-800 border border-slate-700 rounded-2xl p-4">
                <div className="flex items-center gap-2 mb-2"><span className="text-2xl">{t.icon}</span><span className="font-black text-yellow-300 text-sm">{t.title}</span></div>
                <p className="text-slate-300 text-xs leading-relaxed">{t.tip}</p>
              </div>
            ))}
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {localMsgs.map((m, i) => (
                <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                  {m.role === "assistant" && (
                    <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-sm flex-shrink-0 mr-2 mt-1">👨‍🏫</div>
                  )}
                  <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${m.role === "user"
                    ? "bg-yellow-400/20 border border-yellow-400/30 text-yellow-100 rounded-br-sm"
                    : "bg-slate-800 text-slate-100 rounded-bl-sm border border-slate-700"
                  }`}>
                    {m.img && <img src={m.img} alt="" className="w-full rounded-xl mb-2 max-h-40 object-cover" />}
                    <span style={{ whiteSpace: "pre-wrap" }}>{m.content}</span>
                    {m.role === "assistant" && m.content === "" && streaming && (
                      <span className="inline-flex gap-1 ml-1">
                        {[0, 1, 2].map(i => (
                          <span key={i} className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce inline-block" style={{ animationDelay: `${i * 0.15}s` }} />
                        ))}
                      </span>
                    )}
                  </div>
                </div>
              ))}
              {/* Quick questions */}
              {localMsgs.length <= 1 && (
                <div className="flex flex-wrap gap-2 justify-center pt-2">
                  {QUICK_Q.map(q => (
                    <button
                      key={q}
                      onClick={() => setInput(q)}
                      className="text-xs bg-indigo-900/60 border border-indigo-700 text-indigo-300 px-3 py-2 rounded-xl hover:bg-indigo-800 transition-all"
                    >
                      {q}
                    </button>
                  ))}
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            {imgPrev && (
              <div className="px-4 pb-2 flex-shrink-0 flex items-center gap-2 bg-slate-900/50">
                <img src={imgPrev} alt="" className="w-12 h-12 rounded-xl object-cover border-2 border-yellow-400" />
                <span className="text-xs text-yellow-300">Photo ready</span>
                <button onClick={() => { setImgB64(null); setImgPrev(null); }} className="text-red-400 text-xs font-bold ml-auto">✕</button>
              </div>
            )}

            <div className="p-4 border-t border-slate-800 flex gap-2 flex-shrink-0 bg-slate-950/60">
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={pickImage} />
              <button
                onClick={() => fileRef.current?.click()}
                className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-base flex-shrink-0 transition-all"
              >📷</button>
              <input
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && !e.shiftKey && send()}
                placeholder="Sawaal likhein ya photo upload karein..."
                className="flex-1 bg-slate-800 border border-slate-700 focus:border-indigo-500 rounded-xl px-3 py-2 text-white placeholder-slate-500 outline-none text-sm"
              />
              <button
                onClick={send}
                disabled={streaming || (!input.trim() && !imgB64)}
                className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-all ${!streaming && (input.trim() || imgB64) ? "bg-indigo-600 hover:bg-indigo-500 text-white" : "bg-slate-800 text-slate-600 cursor-not-allowed"}`}
              >
                {streaming ? "⏳" : "➤"}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
