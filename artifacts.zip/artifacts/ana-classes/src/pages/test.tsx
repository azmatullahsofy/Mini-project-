import { useState, useEffect, useRef } from "react";
import { SUBJECTS_BY_CLASS, SECTIONS, GENDERS, SUBJECT_EMOJI } from "@/lib/constants";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

interface Question {
  question: string;
  options: string[];
  correctAnswer: number;
}

type Stage = "setup" | "quiz" | "result";

async function generateQuiz(cls: number, subject: string): Promise<Question[]> {
  // Create a temp conversation
  const convRes = await fetch(`${BASE}/api/anthropic/conversations`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title: `Quiz Gen - Class ${cls} ${subject}` }),
  });
  const conv = await convRes.json();

  const prompt = `Generate exactly 10 multiple choice questions for Class ${cls} ${subject}.
Return ONLY a valid JSON array, no other text. Format:
[{"question":"...","options":["A","B","C","D"],"correctAnswer":0}]
correctAnswer is 0-based index. Questions should be appropriate for Class ${cls} level.`;

  let fullText = "";
  const res = await fetch(`${BASE}/api/anthropic/conversations/${conv.id}/messages`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ content: prompt }),
  });

  if (!res.body) throw new Error("No response body");
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() || "";
    for (const line of lines) {
      if (line.startsWith("data: ")) {
        try {
          const json = JSON.parse(line.slice(6));
          if (json.content) fullText += json.content;
          if (json.done) break;
        } catch { /* ignore */ }
      }
    }
  }

  // Parse JSON from response
  const match = fullText.match(/\[[\s\S]*\]/);
  if (!match) throw new Error("Could not parse questions");
  return JSON.parse(match[0]) as Question[];
}

async function explainQuestion(q: Question, cls: number, subject: string): Promise<string> {
  const convRes = await fetch(`${BASE}/api/anthropic/conversations`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title: `Explanation` }),
  });
  const conv = await convRes.json();

  const prompt = `You are Nematullah Sir, a warm Class ${cls} ${subject} teacher. Explain this question in Hinglish (Hindi+English mix), step by step, with emojis. Be warm and encouraging.

Question: ${q.question}
Options: ${q.options.map((o, i) => `${["A","B","C","D"][i]}) ${o}`).join(" | ")}
Correct Answer: ${["A","B","C","D"][q.correctAnswer]}) ${q.options[q.correctAnswer]}`;

  let text = "";
  const res = await fetch(`${BASE}/api/anthropic/conversations/${conv.id}/messages`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ content: prompt }),
  });

  if (!res.body) return "";
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() || "";
    for (const line of lines) {
      if (line.startsWith("data: ")) {
        try {
          const json = JSON.parse(line.slice(6));
          if (json.content) text += json.content;
          if (json.done) break;
        } catch { /* ignore */ }
      }
    }
  }
  return text;
}

function ExplainModal({ question, cls, subject, onClose }: { question: Question; cls: number; subject: string; onClose: () => void }) {
  const [ans, setAns] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    explainQuestion(question, cls, subject).then(t => { setAns(t); setLoading(false); }).catch(() => { setAns("Sorry, abhi explain nahi ho paya. Dobara try karo! 🙏"); setLoading(false); });
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end justify-center p-4">
      <div className="w-full max-w-lg bg-slate-900 border border-indigo-500/40 rounded-3xl overflow-hidden shadow-2xl">
        <div className="bg-gradient-to-r from-indigo-700 to-purple-700 p-4 flex items-center gap-3">
          <span className="text-2xl">👨‍🏫</span>
          <div className="flex-1"><div className="font-black text-white text-sm">Nematullah Sir Samjha Rahe Hain</div><div className="text-xs text-purple-200">{subject} · Class {cls}</div></div>
          <button onClick={onClose} className="text-white/60 hover:text-white font-black text-xl w-8 h-8 flex items-center justify-center">✕</button>
        </div>
        <div className="p-4 max-h-72 overflow-y-auto">
          <div className="bg-slate-800 rounded-xl p-3 mb-3 text-xs text-slate-300 border border-slate-700">❓ {question.question}</div>
          {loading
            ? <div className="flex items-center gap-3 py-6 justify-center"><div className="animate-spin w-6 h-6 border-2 border-indigo-400 border-t-transparent rounded-full" /><span className="text-indigo-300 text-sm">Sir samjha rahe hain...</span></div>
            : <div className="text-slate-200 text-sm leading-relaxed whitespace-pre-wrap">{ans}</div>
          }
        </div>
        <div className="p-4 border-t border-slate-700">
          <button onClick={onClose} className="w-full py-3 rounded-xl font-black text-sm bg-gradient-to-r from-indigo-500 to-purple-500 text-white hover:scale-105 transition-all">
            Samajh Gaya! Wapas Jao
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Test() {
  const [stage, setStage] = useState<Stage>("setup");
  const [cls, setCls] = useState(10);
  const [section, setSection] = useState("A");
  const [subject, setSubject] = useState("");
  const [name, setName] = useState("");
  const [gender, setGender] = useState("Male");
  const [roll, setRoll] = useState("");
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<(number | null)[]>([]);
  const [current, setCurrent] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [timer, setTimer] = useState(600); // 10 min
  const [explainQ, setExplainQ] = useState<Question | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const subjects = SUBJECTS_BY_CLASS[cls] || [];

  useEffect(() => {
    if (!subject && subjects.length > 0) setSubject(subjects[0]);
  }, [cls]);

  useEffect(() => {
    if (stage === "quiz") {
      timerRef.current = setInterval(() => {
        setTimer(t => {
          if (t <= 1) { clearInterval(timerRef.current!); setStage("result"); return 0; }
          return t - 1;
        });
      }, 1000);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [stage]);

  const startTest = async () => {
    if (!name.trim()) { setError("Apna naam likho!"); return; }
    setError("");
    setLoading(true);
    try {
      const qs = await generateQuiz(cls, subject);
      setQuestions(qs);
      setAnswers(new Array(qs.length).fill(null));
      setCurrent(0);
      setTimer(600);
      setStage("quiz");
    } catch {
      setError("Questions generate nahi hue. Internet check karo aur dobara try karo.");
    }
    setLoading(false);
  };

  const selectAnswer = (optIdx: number) => {
    if (answers[current] !== null) return;
    setAnswers(p => { const a = [...p]; a[current] = optIdx; return a; });
  };

  const score = answers.filter((a, i) => a === questions[i]?.correctAnswer).length;
  const attempted = answers.filter(a => a !== null).length;

  const formatTime = (s: number) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

  const INP = "w-full bg-slate-800 border-2 border-slate-700 focus:border-indigo-500 rounded-xl px-4 py-3 text-white placeholder-slate-500 outline-none transition-all text-sm font-medium";
  const SEL = "w-full bg-slate-800 border-2 border-slate-700 focus:border-indigo-500 rounded-xl px-3 py-3 text-white outline-none text-sm font-semibold";

  if (stage === "setup") return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 text-white px-4 py-12">
      {explainQ && <ExplainModal question={explainQ} cls={cls} subject={subject} onClose={() => setExplainQ(null)} />}
      <div className="max-w-lg mx-auto">
        <div className="text-center mb-10">
          <div className="text-5xl mb-4">📝</div>
          <h1 className="text-3xl font-black text-white mb-2">Online Test</h1>
          <p className="text-slate-400 text-sm">AI-generated MCQ test • 10 questions • 10 minutes</p>
        </div>

        <div className="bg-slate-800/60 border border-slate-700 rounded-3xl p-6 space-y-5">
          <div>
            <label className="text-xs font-bold text-slate-400 mb-2 block">STUDENT NAME</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="Apna poora naam likhein" className={INP} />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-400 mb-2 block">GENDER</label>
              <select value={gender} onChange={e => setGender(e.target.value)} className={SEL}>
                {GENDERS.map(g => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-bold text-slate-400 mb-2 block">ROLL NUMBER</label>
              <input value={roll} onChange={e => setRoll(e.target.value)} placeholder="Roll no." className={INP} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-400 mb-2 block">CLASS</label>
              <select value={cls} onChange={e => { setCls(Number(e.target.value)); setSubject(""); }} className={SEL}>
                {Array.from({ length: 12 }, (_, i) => i + 1).map(c => <option key={c} value={c}>Class {c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-bold text-slate-400 mb-2 block">SECTION</label>
              <select value={section} onChange={e => setSection(e.target.value)} className={SEL}>
                {SECTIONS.map(s => <option key={s} value={s}>Section {s}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-400 mb-2 block">SUBJECT</label>
            <select value={subject} onChange={e => setSubject(e.target.value)} className={SEL}>
              {subjects.map(s => <option key={s} value={s}>{SUBJECT_EMOJI[s]} {s}</option>)}
            </select>
          </div>

          {error && <p className="text-red-400 text-sm font-semibold">{error}</p>}

          <button
            onClick={startTest}
            disabled={loading}
            className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-black py-4 rounded-2xl hover:scale-105 transition-all disabled:opacity-50 disabled:scale-100 text-base shadow-xl shadow-indigo-500/20"
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Questions ban rahe hain...
              </span>
            ) : "Test Shuru Karo!"}
          </button>
        </div>
      </div>
    </div>
  );

  if (stage === "quiz") {
    const q = questions[current];
    const answered = answers[current];
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 text-white px-4 py-6">
        {explainQ && <ExplainModal question={explainQ} cls={cls} subject={subject} onClose={() => setExplainQ(null)} />}
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <div className="font-black text-white text-sm">{name} · Class {cls}{section}</div>
              <div className="text-xs text-indigo-400">{subject}</div>
            </div>
            <div className={`font-black text-xl px-4 py-2 rounded-xl ${timer <= 60 ? "bg-red-600/20 text-red-400 border border-red-600/30" : "bg-slate-800 text-white border border-slate-700"}`}>
              ⏱ {formatTime(timer)}
            </div>
          </div>

          {/* Progress */}
          <div className="mb-6">
            <div className="flex justify-between text-xs text-slate-400 mb-2">
              <span>Question {current + 1} of {questions.length}</span>
              <span>{attempted} attempted</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-2">
              <div className="h-2 rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-300" style={{ width: `${((current + 1) / questions.length) * 100}%` }} />
            </div>
          </div>

          {/* Question */}
          <div className="bg-slate-800/60 border border-slate-700 rounded-2xl p-6 mb-4">
            <div className="text-white font-bold text-base leading-relaxed mb-6">{q?.question}</div>
            <div className="space-y-3">
              {q?.options.map((opt, i) => {
                let style = "bg-slate-900/60 border-slate-700 text-slate-200 hover:border-indigo-500 hover:bg-indigo-900/20";
                if (answered !== null) {
                  if (i === q.correctAnswer) style = "bg-green-900/40 border-green-500 text-green-200";
                  else if (i === answered) style = "bg-red-900/40 border-red-500 text-red-200";
                  else style = "bg-slate-900/30 border-slate-800 text-slate-500";
                }
                return (
                  <button
                    key={i}
                    onClick={() => selectAnswer(i)}
                    disabled={answered !== null}
                    className={`w-full text-left px-4 py-3 rounded-xl border-2 text-sm font-medium transition-all ${style}`}
                  >
                    <span className="font-black mr-2">{["A", "B", "C", "D"][i]}.</span>{opt}
                  </button>
                );
              })}
            </div>
          </div>

          {answered !== null && (
            <div className={`text-center text-sm font-bold mb-4 px-4 py-2 rounded-xl ${answered === q?.correctAnswer ? "bg-green-900/30 text-green-400 border border-green-700" : "bg-red-900/30 text-red-400 border border-red-700"}`}>
              {answered === q?.correctAnswer ? "Sahi Jawab! Bahut badhiya! 🎉" : `Galat. Sahi jawab: ${["A", "B", "C", "D"][q?.correctAnswer ?? 0]}) ${q?.options[q?.correctAnswer ?? 0]}`}
            </div>
          )}

          {/* Navigation */}
          <div className="flex gap-3 mb-4">
            <button onClick={() => setCurrent(c => Math.max(0, c - 1))} disabled={current === 0} className="flex-1 py-3 rounded-xl bg-slate-800 border border-slate-700 text-sm font-bold disabled:opacity-40 hover:bg-slate-700 transition-all">
              ← Pichla
            </button>
            {answered !== null && (
              <button onClick={() => setExplainQ(q)} className="flex-1 py-3 rounded-xl bg-indigo-900/40 border border-indigo-600/40 text-indigo-300 text-sm font-bold hover:bg-indigo-900/60 transition-all">
                👨‍🏫 Sir Se Poochho
              </button>
            )}
            {current < questions.length - 1
              ? <button onClick={() => setCurrent(c => c + 1)} className="flex-1 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-sm font-bold hover:scale-105 transition-all">Agla →</button>
              : <button onClick={() => setStage("result")} className="flex-1 py-3 rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 text-white text-sm font-bold hover:scale-105 transition-all">Submit Test</button>
            }
          </div>

          {/* Question dots */}
          <div className="flex flex-wrap gap-1.5 justify-center">
            {questions.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${i === current ? "bg-indigo-600 text-white" : answers[i] !== null ? (answers[i] === questions[i].correctAnswer ? "bg-green-800 text-green-300" : "bg-red-800 text-red-300") : "bg-slate-800 text-slate-400 hover:bg-slate-700"}`}
              >
                {i + 1}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Result stage
  const pct = questions.length ? Math.round((score / questions.length) * 100) : 0;
  const grade = pct >= 90 ? "A+" : pct >= 80 ? "A" : pct >= 70 ? "B" : pct >= 60 ? "C" : pct >= 50 ? "D" : "F";
  const msg = pct >= 80 ? "Kamaal kar diya! Bahut badhiya performance! 🏆" : pct >= 60 ? "Achha kiya! Thoda aur mehnat karo. 💪" : "Ghabrao mat! Revision karo, agli baar zaroor sudhrega. 🌟";

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 text-white px-4 py-12">
      <div className="max-w-lg mx-auto text-center">
        <div className="text-7xl mb-4">{pct >= 80 ? "🏆" : pct >= 60 ? "👍" : "📚"}</div>
        <h1 className="text-3xl font-black text-white mb-2">Test Complete!</h1>
        <p className="text-slate-400 text-sm mb-8">{name} · Class {cls}{section} · {subject}</p>

        <div className="bg-slate-800/60 border border-slate-700 rounded-3xl p-8 mb-6">
          <div className="text-8xl font-black bg-gradient-to-br from-yellow-400 to-amber-400 bg-clip-text text-transparent mb-2">{pct}%</div>
          <div className="text-3xl font-black text-white mb-1">Grade: {grade}</div>
          <div className="text-slate-400 text-sm mb-6">{score} / {questions.length} sahi</div>
          <p className="text-white font-semibold text-base">{msg}</p>
        </div>

        <div className="grid grid-cols-3 gap-3 mb-8">
          {[{ label: "Sahi", val: score, color: "text-green-400" }, { label: "Galat", val: questions.length - score, color: "text-red-400" }, { label: "Skipped", val: questions.length - attempted, color: "text-yellow-400" }].map(s => (
            <div key={s.label} className="bg-slate-800/60 border border-slate-700 rounded-2xl p-4">
              <div className={`text-2xl font-black ${s.color}`}>{s.val}</div>
              <div className="text-xs text-slate-400 font-semibold mt-1">{s.label}</div>
            </div>
          ))}
        </div>

        <div className="flex gap-3">
          <button onClick={() => { setStage("setup"); setQuestions([]); setAnswers([]); }} className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-black hover:scale-105 transition-all">
            Dobara Test Do
          </button>
        </div>
      </div>
    </div>
  );
}
